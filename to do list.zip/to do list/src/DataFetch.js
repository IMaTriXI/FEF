import React, { useEffect, useState} from 'react'

const Datafetch = () => {
    const [data,setData]= useState([]);

    useEffect(()=>{
        fetch("http://jsonplaceholder.typicode.com/posts")
        .then(async function(res){
            const json = await res.json();
            setData(json);
        })
    },[data])
    return(
        <div>
            <div>
                <input type='text' placeholder='Enter title' value={search} onChange={()}></input>
            </div>
        </div>
    )
}