// src/App.js
import React, { useState } from 'react';
import './App.css';
import TaskList from './TaskList';
import AddTask from './AddTask';

const App = () => {
  const [tasks, setTasks] = useState([]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const checkTasks = () => {
    alert(JSON.stringify(tasks, null, 2)); // Display tasks in an alert
    // Alternatively, use console.log(tasks) to log tasks to the console
  };

  return (
    <div className="App">
      <h1>Task List</h1>
      <AddTask onAdd={addTask} />
      <TaskList tasks={tasks} />
      <button onClick={checkTasks} style={{ marginTop: '20px' }}>
        Check Stored Tasks
      </button>
    </div>
  );
};

export default App;
