import React, { useState } from 'react';
import ProductUpdater from './ProductUpdater';

const ProductDetails = () => {
  const [product, setProduct] = useState({
    name: 'React Handbook',
    price: 29.99,
    description: 'A comprehensive guide to learn React from scratch.',
  });

  const updateProductDetails = () => {
    setProduct({
      name: 'Advanced React Patterns',
      price: 39.99,
      description: 'Explore advanced patterns and best practices in React.',
    });
  };

  return (
    <div className="product-card">
      <h2 className="product-title">{product.name}</h2>
      <p className="product-price">${product.price.toFixed(2)}</p>
      <p className="product-description">{product.description}</p>

      <ProductUpdater updateProduct={updateProductDetails} />
    </div>
  );
};

export default ProductDetails;
