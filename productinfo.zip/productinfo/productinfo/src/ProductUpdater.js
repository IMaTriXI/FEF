import React from 'react';
import PropTypes from 'prop-types';

const ProductUpdater = ({ updateProduct }) => {
  return (
    <button className="update-button" onClick={updateProduct}>
      Update Product Details
    </button>
  );
};

ProductUpdater.propTypes = {
  updateProduct: PropTypes.func.isRequired,
};

export default ProductUpdater;
