import React from 'react';
import ProductDetails from './ProductDetails';
import './App.css'; 

const App = () => {
  return (
    <div className="app">
      <h1 className="title">Product Information</h1>
      <ProductDetails />
    </div>
  );
};

export default App;
