import React, { useState } from 'react';
import './App.css'; 

function App() {
  const [users, setUsers] = useState([]); 
  const [name, setName] = useState(''); 
  const [age, setAge] = useState(''); 
  const [occupation, setOccupation] = useState(''); 

  
  const handleSubmit = (e) => {
    e.preventDefault(); 
    const newUser = { id: Date.now(), name, age, occupation }; 
    setUsers([...users, newUser]); 
    setName(''); 
    setAge(''); 
    setOccupation(''); 
  };

  return (
    <div className="App">
      <h1>User Profiles</h1>

      {/* Form to add new users */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Occupation"
          value={occupation}
          onChange={(e) => setOccupation(e.target.value)}
          required
        />
        <button type="submit">Add User</button>
      </form>

      {users.length === 0 ? (
        <p>No users available</p>
      ) : (
        <div className="user-list">
          {/* Column titles */}
          <div className="user-header">
            <span>Name</span>
            <span>Age</span>
            <span>Occupation</span>
          </div>

          <ul>
            {users.map((user) => (
              <li key={user.id}>
                <span>{user.name}</span>
                <span>{user.age} years</span>
                <span>{user.occupation}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
