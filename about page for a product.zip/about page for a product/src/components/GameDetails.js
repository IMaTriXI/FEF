// GameDetails.js
import React, { useContext, useState } from "react";
import { AppContext } from "../AppContext"; // Import your context
import './GameDetails.css'; // Assuming you have a CSS file for GameDetails

const GameDetails = () => {
  const { darkMode, toggleDarkMode } = useContext(AppContext); // Access the context
  const headerImageUrl = "https://pbs.twimg.com/media/GAyylTUXcAAelnX.png";
  
  // State for the full-screen image
  const [fullScreenImage, setFullScreenImage] = useState(null);
  
  const handleImageClick = (src) => {
    setFullScreenImage(src);
    setTimeout(() => {
      setFullScreenImage(null);
    }, 3000); // Show full-screen image for 3 seconds
  };

  // Fallback image if any image fails to load
  const handleError = (e) => {
    e.target.src = "https://via.placeholder.com/1200x675?text=Image+Not+Available";
  };

  return (
    <div className={`game-details ${darkMode ? 'dark' : 'light'}`}>
      {/* Dark Mode Switch */}
      <button onClick={toggleDarkMode}>
        {darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      </button>

      {/* Fullscreen Image */}
      {fullScreenImage && (
        <div className="full-screen">
          <img src={fullScreenImage} alt="Full Screen" onClick={() => setFullScreenImage(null)} />
        </div>
      )}

      {/* Heading Image */}
      <header className="game-header">
        <img src={headerImageUrl} alt="Dragon Ball Z Sparking Zero" className="game-header-img" />
      </header>

      {/* Description Section */}
      <section>
        <h2>Description</h2>
        <p>
          Dragon Ball Sparking Zero ushers the popular 3D arena brawler onto current-gen platforms
          and we expect it to take advantage of all the latest tech to ensure the fighting game looks and feels as smooth as ever.
          Aside from the core gameplay mechanics that define the Budokai Tenkaichi series,
          Sparking Zero is also set to include “genre-defining features” to create
          “one of the most immersive anime game experiences of all time” according to Bandai Namco CEO Arnaud Muller.
          Dragon Ball Sparking Zero will be available on PC via Steam, as well as on PlayStation 5 and Xbox Series X|S for console users. Fans will be able to purchase a deluxe edition, which, in addition to being able to play earlier than the release date, will also include the Season Pass that unlocks early access to over 20 playable characters from Dragon Ball Super Hero and Dragon Ball Daima, as well as Shenron as a bonus.
          The Ultimate Edition comes with Super Shenron and the Ultimate Upgrade pack, which includes a Goku (Super) Costume with Power Pole, one customization item, an emote voice set, and two-player card backgrounds. Pre-orders for all versions include unlocks for all Gogeta and Broly’s forms and an additional playable character.

          There’s also a possibility that Dragon Ball Sparking Zero might be an upcoming Game Pass game, given that we’ve seen Dragon Ball FighterZ on Game Pass back in 2022. However, Bandai Namco has not indicated it will be available on the subscription service at launch.
        </p>
      </section>

      {/* Screenshots Section */}
      <section className="screenshots">
        <h2>Screenshots</h2>
        <img
          src="https://p325k7wa.twic.pics/high/dragon-ball/dragon-ball-sparking-zero/00-page-setup/Page-Setup-Revamp/DBSZ_banner_mobile.jpg?twic=v1/resize=760/step=10/quality=80"
          alt="Screenshot 1"
          onClick={() => handleImageClick("https://p325k7wa.twic.pics/high/dragon-ball/dragon-ball-sparking-zero/00-page-setup/Page-Setup-Revamp/DBSZ_banner_mobile.jpg?twic=v1/resize=760/step=10/quality=80")}
          onError={handleError}
        />
        <img
          src="https://p325k7wa.twic.pics/high/dragon-ball/dragon-ball-sparking-zero/00-page-setup/dbsz-keyfeature-3D-Fights.png?twic=v1/resize=700/step=10/quality=80"
          alt="Screenshot 2"
          onClick={() => handleImageClick("https://p325k7wa.twic.pics/high/dragon-ball/dragon-ball-sparking-zero/00-page-setup/dbsz-keyfeature-3D-Fights.png?twic=v1/resize=700/step=10/quality=80")}
          onError={handleError}
        />
      </section>

      {/* Platform and Release Date Sections */}
      <section>
        <h2>Platform</h2>
        <p>PlayStation 4, Xbox One, PC</p>
      </section>
      <section>
        <h2>Release Date</h2>
        <p>The official release date for Dragon Ball Sparking Zero is October 11, 2024, as confirmed during the Summer Games Fest. Those who buy the Ultimate Edition or higher tiers can access the game three days early.</p>
      </section>
    </div>
  );
};

export default GameDetails;