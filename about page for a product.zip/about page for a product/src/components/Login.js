import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    // Retrieve the stored credentials from localStorage
    const storedUserData = JSON.parse(localStorage.getItem("userCredentials"));

    if (storedUserData) {
      const hashedPassword = btoa(password); // Encode the entered password to compare with the stored one

      // Validate credentials
      if (storedUserData.email === email && storedUserData.password === hashedPassword) {
        alert("Login successful!");
        // Redirect to game details page after successful login
        navigate('/game-details');
      } else {
        setError("Invalid email or password");
      }
    } else {
      setError("No user found. Please sign up.");
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p style={{ color: "red" }}>{error}</p>}
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
