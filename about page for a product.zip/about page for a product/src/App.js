// App.js
import React from 'react';
import GameDetails from './components/GameDetails'; // Update the path as necessary

const App = () => {
  return (
    <div>
      <GameDetails />
    </div>
  );
};

export default App;
